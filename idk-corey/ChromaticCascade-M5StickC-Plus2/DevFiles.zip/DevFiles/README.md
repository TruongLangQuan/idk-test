# M5StickC Plus2 Audio Spectrum Analyzer

Audio Spectrum Display, Oscilloscope, and Tuner for M5StickC Plus2

Ported from the original M5StickC Plus1 version by KIRA Ryouta.

## Features

- **Audio Spectrum Display** - Real-time frequency analysis with 8 bands
- **Oscilloscope** - Time domain waveform display  
- **Tuner** - Musical note detection and pitch accuracy
- **🌈 Audio Circles** - Psychedelic concentric circles that pulse with audio
- **🔥 Audio Plasma** - Classic plasma field that reacts to sound intensity  
- **✨ Audio Fireworks** - Sparkly fireworks that launch based on frequency bands

**Button Controls:**
- **Button A**: Cycle through original modes: Audio Spectrum → Oscilloscope → Tuner  
- **Button B**: Cycle through psychedelic modes: Audio Spectrum → Audio Circles → Audio Plasma → Audio Fireworks

## Hardware Requirements

- M5StickC Plus2
- Built-in I2S microphone (pins 0 and 34)

## Build Instructions

This project uses PlatformIO:

```bash
# Build the project
pio run

# Upload to device
pio run --target upload

# Monitor serial output
pio device monitor
```

## Technical Details

- **Display**: 135x240 pixels (landscape orientation)
- **Audio Processing**: Fixed-point FFT for efficient spectrum analysis
- **Sample Rate**: 8kHz optimized for voice/music
- **Frequency Range**: 125Hz to 16kHz across 8 bands

## Libraries Used

- M5StickCPlus2 v1.0.2+
- Custom fixed-point FFT implementation
- DyWaPitchTrack for pitch detection

## Original Credits

- Original M5StickC version: KIRA Ryouta (https://github.com/KKQ-KKQ/m5stickc-audiospectrum)
- FFT implementation: David Bird & macsbug
- Pitch tracking: DyWaPitchTrack library

## License

MIT License - See LICENSE file for details