# BeaconMaster v1.0 - M5Burner Package

## 🚀 Installation
1. Download `BeaconMaster-v1.0-FINAL.bin`
2. Open M5Burner
3. Select M5StickC Plus2 device  
4. Load the .bin file
5. Flash at address 0x0 (automatic)
6. Enjoy!

## 📋 File Info
- **Size**: 1023472 bytes
- **MD5**: 3dc6cc385b1182659dc6ed8be54a05ce
- **Flash Address**: 0x0 (merged binary)

## 🛠️ Hardware Required
- M5StickC Plus2

**This firmware has been tested and verified working with M5Burner!** ✅
